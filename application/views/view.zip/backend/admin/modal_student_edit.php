<style>
    .cp-studying th{
        text-align: center !important;
    }
    .h_plus{
        width: 10%;
        float: left;
        padding-top: 5%;
    }
    .h_input{
        width: 90% !important;
        float: left;
    }
    .cl{
        font-size: 15px;
        width: 100%;
        text-align: center !important;
        margin-bottom: 2% !important;
    }
    .modal-dialog {
        width: 960px !important;
        padding-top: 30px;
        padding-bottom: 30px;
    }
</style>
<?php
$edit_data		=	$this->db->get_where('student' , array('student_id' => $param2) )->result_array();
foreach ( $edit_data as $row):
?>
<div class="row">
	<div class="col-md-12">
		<div class="panel panel-primary" data-collapsed="0">
        	<div class="panel-heading">
            	<div class="panel-title" >
            		<i class="entypo-plus-circled"></i>
					<?php echo get_phrase('edit_student');?>
            	</div>
            </div>
			<div class="panel-body">
				
                <?php echo form_open(base_url() . 'index.php?admin/student/'.$row['class_id'].'/do_update/'.$row['student_id'] , array('class' => 'form-horizontal form-groups-bordered validate', 'enctype' => 'multipart/form-data'));?>
                
                	
	
					<div class="form-group">
						<label for="field-1" class="col-sm-3 control-label"><?php echo get_phrase('photo');?></label>
                        
						<div class="col-sm-5">
							<div class="fileinput fileinput-new" data-provides="fileinput">
								<div class="fileinput-new thumbnail" style="width: 100px; height: 100px;" data-trigger="fileinput">
									<img src="<?php echo $this->crud_model->get_image_url('student' , $row['student_id']);?>" alt="...">
								</div>
								<div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 200px; max-height: 150px"></div>
								<div>
									<span class="btn btn-white btn-file">
										<span class="fileinput-new">Select image</span>
										<span class="fileinput-exists">Change</span>
										<input type="file" name="userfile" accept="image/*">
									</span>
									<a href="#" class="btn btn-orange fileinput-exists" data-dismiss="fileinput">Remove</a>
								</div>
							</div>
						</div>
					</div>
	
					<div class="form-group">
						<label for="field-1" class="col-sm-3 control-label"><?php echo get_phrase('name');?></label>
                        
						<div class="col-sm-5">
							<input type="text" class="form-control" name="name" data-validate="required" data-message-required="<?php echo get_phrase('value_required');?>" value="<?php echo $row['name'];?>">
						</div>
					</div>

                    <div class="form-group">
                        <label for="field-2" class="col-sm-3 control-label"><?php echo get_phrase('gender');?></label>

                        <div class="col-sm-5">
                            <select name="gender" class="form-control">
                                <option value=""><?php echo get_phrase('select');?></option>
                                <option value="male" <?php if($row['sex'] == 'male')echo 'selected';?>><?php echo get_phrase('male');?></option>
                                <option value="female"<?php if($row['sex'] == 'female')echo 'selected';?>><?php echo get_phrase('female');?></option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="field-2" class="col-sm-3 control-label"><?php echo get_phrase('present address');?></label>

                        <div class="col-sm-5">
                            <input type="text" class="form-control" name="present_address" value="<?php echo $row['present_address'];?>" >
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="field-2" class="col-sm-3 control-label"><?php echo get_phrase('phone');?></label>

                        <div class="col-sm-5">
                            <input type="text" class="form-control" name="phone" value="<?php echo $row['phone'];?>" >
                        </div>
                    </div>


                    <div class="form-group">
                        <label for="field-2" class="col-sm-3 control-label"><?php echo get_phrase('birthday');?></label>

                        <div class="col-sm-5">
                            <input type="text" class="form-control datepicker" name="birthday" value="<?php echo $row['birthday'];?>" data-start-view="2">
                        </div>
                    </div>

					<div class="form-group">
						<label for="field-2" class="col-sm-3 control-label"><?php echo get_phrase('parent');?></label>
                        
						<div class="col-sm-5">
							<select name="parent_id" class="form-control" data-validate="required" data-message-required="<?php echo get_phrase('value_required');?>">
                              <option value=""><?php echo get_phrase('select');?></option>
                              <?php 
									$parents = $this->db->get('parent')->result_array();
									foreach($parents as $row3):
										?>
                                		<option value="<?php echo $row3['parent_id'];?>"
                                        	<?php if($row['parent_id'] == $row3['parent_id'])echo 'selected';?>>
													<?php echo $row3['father_name'];?>
                                                </option>
	                                <?php
									endforeach;
								  ?>
                          </select>
						</div> 
					</div>
					
					<div class="form-group">
						<label for="field-2" class="col-sm-3 control-label"><?php echo get_phrase('class');?></label>
                        
						<div class="col-sm-5">
							<select name="class_id" class="form-control" data-validate="required" id="class_id" 
								data-message-required="<?php echo get_phrase('value_required');?>"
									onchange="return get_class_sections(this.value)">
                              <option value=""><?php echo get_phrase('select');?></option>
                              <?php 
									$classes = $this->db->get('class')->result_array();
									foreach($classes as $row2):
										?>
                                		<option value="<?php echo $row2['class_id'];?>"
                                        	<?php if($row['class_id'] == $row2['class_id'])echo 'selected';?>>
													<?php echo $row2['name'];?>
                                                </option>
	                                <?php
									endforeach;
								  ?>
                          </select>
						</div> 
					</div>

					
						<div class="form-group">
							<label for="field-2" class="col-sm-3 control-label"><?php echo get_phrase('section');?></label>
			                    <div class="col-sm-5">
			                        <select name="section_id" class="form-control" id="section_selector_holder">
			                            <option value=""><?php echo get_phrase('select_class_first');?></option>
				                        
				                    </select>
				                </div>
						</div>
					
					
					<div class="form-group">
						<label for="field-2" class="col-sm-3 control-label"><?php echo get_phrase('Student ID');?></label>
                        
						<div class="col-sm-5">
							<input type="text" class="form-control" name="roll" value="<?php echo $row['roll'];?>" >
						</div> 
					</div>
					

					<div class="form-group">
						<label for="field-1" class="col-sm-3 control-label"><?php echo get_phrase('email');?></label>
						<div class="col-sm-5">
							<input type="text" class="form-control" name="email" value="<?php echo $row['email'];?>">
						</div>
					</div>

                    <div class="form-group">
                        <label for="field-2" class="col-sm-8 control-label cl"><?php echo get_phrase('Information of The Student is Currently Studying Or Has Previously Studied(Not Applicable for PLAY Group)');?></label>
                        <div class="col-sm-12">
                            <table class="cp-studying" style="width:100%" border="1">
                                <thead>
                                    <tr>
                                        <th>NAME OF INSTITUTION</th>
                                        <th>CLASS</th>
                                        <th>YEAR</th>
                                        <th>POSITION</th>
                                        <th>PASSED/PROMOTION ON TRIAL</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><input type="text" class="form-control" name="institution_1" value="<?php echo $row['institution_1'];?>" autofocus></td>
                                        <td><input type="text" class="form-control" name="class_1" value="<?php echo $row['class_1'];?>" autofocus></td>
                                        <td><input type="text" class="form-control" name="year_1" value="<?php echo $row['year_1'];?>" autofocus></td>
                                        <td><input type="text" class="form-control" name="position_1" value="<?php echo $row['position_1'];?>" autofocus></td>
                                        <td><input type="text" class="form-control" name="passed_1" value="<?php echo $row['passed_1'];?>" autofocus></td>
                                    </tr>
                                    <tr>
                                        <td><input type="text" class="form-control" name="institution_2" value="<?php echo $row['institution_2'];?>" autofocus></td>
                                        <td><input type="text" class="form-control" name="class_2" value="<?php echo $row['class_2'];?>" autofocus></td>
                                        <td><input type="text" class="form-control" name="year_2" value="<?php echo $row['year_2'];?>" autofocus></td>
                                        <td><input type="text" class="form-control" name="position_2" value="<?php echo $row['position_2'];?>" autofocus></td>
                                        <td><input type="text" class="form-control" name="passed_2" value="<?php echo $row['passed_2'];?>" autofocus></td>
                                    </tr>
                                    <tr>
                                        <td><input type="text" class="form-control" name="institution_3" value="<?php echo $row['institution_3'];?>" autofocus></td>
                                        <td><input type="text" class="form-control" name="class_3" value="<?php echo $row['class_3'];?>" autofocus></td>
                                        <td><input type="text" class="form-control" name="year_3" value="<?php echo $row['year_3'];?>" autofocus></td>
                                        <td><input type="text" class="form-control" name="position_3" value="<?php echo $row['position_3'];?>" autofocus></td>
                                        <td><input type="text" class="form-control" name="passed_3" value="<?php echo $row['passed_3'];?>" autofocus></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>


                    <div class="form-group">
                        <label for="field-2" class="col-sm-3 control-label"><?php echo get_phrase('Reason For Leaving Institution');?></label>

                        <div class="col-sm-5">
                            <textarea rows="5" cols="50" name="reason_for_leaving"><?php echo $row['reason_for_leaving'];?></textarea>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="field-2" class="col-sm-5 control-label cl"><?php echo get_phrase('Names of Brothers/Sisters Currently Studying in This Institution');?></label>
                        <div class="col-sm-12">
                            <table class="cp-studying" style="width:100%" border="1">
                                <thead>
                                    <tr>
                                        <th>NAME OF BROTHERS/SISTERS</th>
                                        <th>CLASS</th>
                                        <th>SECTION</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><input type="text" class="form-control" name="c_brother_1" value="<?php echo $row['c_brother_1'];?>" autofocus></td>
                                        <td><input type="text" class="form-control" name="cb_class_1" value="<?php echo $row['cb_class_1'];?>" autofocus></td>
                                        <td><input type="text" class="form-control" name="cb_section_1" value="<?php echo $row['cb_section_1'];?>" autofocus></td>
                                    </tr>
                                    <tr>
                                        <td><input type="text" class="form-control" name="c_brother_2" value="<?php echo $row['c_brother_2'];?>" autofocus></td>
                                        <td><input type="text" class="form-control" name="cb_class_2" value="<?php echo $row['cb_class_2'];?>" autofocus></td>
                                        <td><input type="text" class="form-control" name="cb_section_2" value="<?php echo $row['cb_section_2'];?>" autofocus></td>
                                    </tr>
                                    <tr>
                                        <td><input type="text" class="form-control" name="c_brother_3" value="<?php echo $row['c_brother_3'];?>" autofocus></td>
                                        <td><input type="text" class="form-control" name="cb_class_3" value="<?php echo $row['cb_class_3'];?>" autofocus></td>
                                        <td><input type="text" class="form-control" name="cb_section_3" value="<?php echo $row['cb_section_3'];?>" autofocus></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>


                    <div class="form-group">
                        <label for="field-2" class="col-sm-5 control-label cl"><?php echo get_phrase('Names of Brothers/Sisters Previously Studying in This Institution');?></label>
                        <div class="col-sm-12">
                            <table class="cp-studying" style="width:100%" border="1">
                                <thead>
                                    <tr>
                                        <th>NAME OF BROTHERS/SISTERS</th>
                                        <th>CLASS</th>
                                        <th>SECTION</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><input type="text" class="form-control" name="p_brothers_1" value="<?php echo $row['p_brothers_1'];?>" autofocus></td>
                                        <td><input type="text" class="form-control" name="pb_class_1" value="<?php echo $row['pb_class_1'];?>" autofocus></td>
                                        <td><input type="text" class="form-control" name="pb_section_1" value="<?php echo $row['pb_section_1'];?>" autofocus></td>
                                    </tr>
                                    <tr>
                                        <td><input type="text" class="form-control" name="p_brothers_2" value="<?php echo $row['p_brothers_2'];?>" autofocus></td>
                                        <td><input type="text" class="form-control" name="pb_class_2" value="<?php echo $row['pb_class_2'];?>" autofocus></td>
                                        <td><input type="text" class="form-control" name="pb_section_2" value="<?php echo $row['pb_section_2'];?>" autofocus></td>
                                    </tr>
                                    <tr>
                                        <td><input type="text" class="form-control" name="p_brothers_3" value="<?php echo $row['p_brothers_3'];?>" autofocus></td>
                                        <td><input type="text" class="form-control" name="pb_class_3" value="<?php echo $row['pb_class_3'];?>" autofocus></td>
                                        <td><input type="text" class="form-control" name="pb_section_3" value="<?php echo $row['pb_section_3'];?>" autofocus></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>


                    <div class="form-group">
                        <label for="field-2" class="col-sm-4 control-label cl"><?php echo get_phrase('This Section is to be Filled up by School Authority');?></label>
                        <div class="col-sm-12">
                            <table class="cp-studying" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>CLASS</th>
                                        <th>MONTHLY TUTION FEES</th>
                                        <th>ADMISSION FEES(FOR NEW STUDENT)</th>
                                        <th>EVALUATION FEES</th>
                                        <th>VAT</th>
                                        <th>TOTAL</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <div class="form-group">

                                                <div class="col-sm-12">
                                                    <select name="fee_class_id" class="form-control" id="fee_class_id"
                                                            data-message-required="<?php echo get_phrase('value_required');?>">
                                                        <?php
                                                        $classes = $this->db->get('class')->result_array();
                                                        foreach($classes as $class):
                                                            $vat = $this->db->get_where('settings', array('type' => 'vat'))->row()->description;
                                                            $fee = $class['monthly_fee'].','.$class['admission_fee'].','.$class['evaluation_fee'].','.$vat;
                                                            if($class['class_id']==$row['s_class']){
                                                                $selected = 'selected';
                                                            }else{
                                                                $selected = '';
                                                            }
                                                            ?>
                                                            <option class="<?php echo $fee;?>" value="<?php echo $class['class_id'];?>" <?php echo $selected;?>>
                                                                <?php echo $class['name'];?>
                                                            </option>
                                                        <?php
                                                        endforeach;
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </td>
                                        <td><input type="text" class="form-control" name="monthly_fees" id="monthly_fees" value="" autofocus readonly></td>
                                        <td><span class="h_plus">+</span><input type="text" class="form-control h_input" name="admission_fees" id="admission_fees" value="" autofocus readonly></td>
                                        <td><span class="h_plus">+</span><input type="text" class="form-control h_input" name="evaluation_fees" id="evaluation_fees" value="" autofocus readonly></td>
                                        <td><span class="h_plus">+</span><input type="text" class="form-control h_input" name="vat" id="vat" value="" autofocus readonly></td>
                                        <td><span class="h_plus">=</span><input type="text" class="form-control h_input" name="total" id="total" value="" autofocus readonly></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>



                    <div class="form-group">
                        <label for="field-2" class="col-sm-3 control-label"><?php echo get_phrase('Student Admitted For The Session');?></label>

                        <div class="col-sm-3">
                            <select class="form-control" name="s_session" id="month" onchange="" size="1">
                                <option value="01" <?php if($row['s_session']=='01')echo 'selected';?>>January</option>
                                <option value="07" <?php if($row['s_session']=='07')echo 'selected';?>>July</option>
                            </select>
                        </div>
                        <div class="col-sm-3">
                            <select class="form-control" name="year" id="year" onchange="" size="1">
                                <?php
                                $year = date('Y');
                                for($i= $year;$i<=$year+5;$i++){
                                    if($row['year']==$i){
                                        $s = 'selected';
                                    }else{
                                        $s = '';
                                    }
                                    echo '<option value="'.$i.'" '.$s.'>'.$i.'</option>';
                                }
                                ?>
                            </select>
                        </div>
                        <div class="form-control s-year" style="display: none;">
                            <?php
                            $year = date('Y');
                            for($i= $year;$i<=$year+5;$i++){
                                echo '<option class="jan" value="'.$i.'">'.$i.'</option>';
                                echo '<option class="july" value="'.$i.'-'.($i+1).'">'.$i.'-'.($i+1).'</option>';
                            }
                            ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="field-2" class="col-sm-3 control-label"><?php echo get_phrase('Building Information');?></label>
                        <div class="col-sm-5">
                            <select name="building_info" class="form-control" id="building_info"
                                    data-message-required="<?php echo get_phrase('value_required');?>">
                                <?php
                                $buildings = $this->db->get('building')->result_array();
                                foreach($buildings as $building):
                                    if($building['id']==$row['building_info']){
                                        $selected = 'selected';
                                    }else{
                                        $selected = '';
                                    }
                                    ?>
                                    <option value="<?php echo $building['id'];?>" <?php echo $selected;?>>
                                        <?php echo $building['building_name'];?>
                                    </option>
                                <?php
                                endforeach;
                                ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
						<div class="col-sm-offset-3 col-sm-5">
							<button type="submit" class="btn btn-info"><?php echo get_phrase('edit_student');?></button>
						</div>
					</div>
                <?php echo form_close();?>
            </div>
        </div>
    </div>
</div>

<?php
endforeach;
?>

<script type="text/javascript">

	function get_class_sections(class_id) {

    	$.ajax({
            url: '<?php echo base_url();?>index.php?admin/get_class_section/' + class_id ,
            success: function(response)
            {
                jQuery('#section_selector_holder').html(response);
            }
        });

    }

    var class_id = $("#class_id").val();
    
    	$.ajax({
            url: '<?php echo base_url();?>index.php?admin/get_class_section/' + class_id ,
            success: function(response)
            {
                jQuery('#section_selector_holder').html(response);
            }
        });

    $(function(){
        var m = $('#month').val();
        var html = '';
        if(m=="01"){
            $('.s-year').find('option').each(function(){
                var t = $(this).html();
                if($(this).hasClass( 'jan' )){
                    html += '<option value="'+t+'">'+t+'</option>';
                }
            });
            $('#year').html(html);
        }else{
            $('.s-year').find('option').each(function(){
                var t = $(this).html();
                if($(this).hasClass( 'july' )){
                    html += '<option value="'+t+'">'+t+'</option>';
                }
            });
            $('#year').html(html);
        }

        //Selected class action for Tutuition fee
        var c = $('#fee_class_id option:selected').attr("class");
        var fees = c.split(",");
        var monthly_fee = parseFloat(fees[0]);
        var admission_fee = parseFloat(fees[1]);
        var evaluation_fee = parseFloat(fees[2]);
        var vat = parseFloat(fees[3]);
        var total = monthly_fee + admission_fee +  evaluation_fee;
        var final_total = total + (total * (vat/100));

        //Putting to necessary field
        $('#monthly_fees').val(monthly_fee);
        $('#admission_fees').val(admission_fee);
        $('#evaluation_fees').val(evaluation_fee);
        $('#vat').val(vat);
        $('#total').val(final_total);
    });

    $('#month').change(function(){
        var m = $('#month').val();
        var html = '';
        if(m=="01"){
            $('.s-year').find('option').each(function(){
                var t = $(this).html();
                if($(this).hasClass( 'jan' )){
                    html += '<option value="'+t+'">'+t+'</option>';
                }
            });
            $('#year').html(html);
        }else{
            $('.s-year').find('option').each(function(){
                var t = $(this).html();
                if($(this).hasClass( 'july' )){
                    html += '<option value="'+t+'">'+t+'</option>';
                }
            });
            $('#year').html(html);
        }
    });

    $(document).delegate('#fee_class_id','change',function(){
        var c = $('#fee_class_id option:selected').attr("class");
        var fees = c.split(",");
        var monthly_fee = parseFloat(fees[0]);
        var admission_fee = parseFloat(fees[1]);
        var evaluation_fee = parseFloat(fees[2]);
        var vat = parseFloat(fees[3]);
        var total = monthly_fee + admission_fee +  evaluation_fee;
        var final_total = total + (total * (vat/100));

        //Putting to necessary field
        $('#monthly_fees').val(monthly_fee);
        $('#admission_fees').val(admission_fee);
        $('#evaluation_fees').val(evaluation_fee);
        $('#vat').val(vat);
        $('#total').val(final_total);
    });


</script>