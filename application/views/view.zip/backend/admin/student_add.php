<style>
    .cp-studying th{
        text-align: center !important;
    }
    .h_plus{
        width: 10%;
        float: left;
        padding-top: 5%;
    }
    .h_input{
        width: 90% !important;
        float: left;
    }
    .cl{
        font-size: 15px;
        width: 100%;
        text-align: center !important;
        margin-bottom: 2% !important;
    }
</style>
<div class="row">
	<div class="col-md-12">
		<div class="panel panel-primary" data-collapsed="0">
        	<div class="panel-heading">
            	<div class="panel-title" >
            		<i class="entypo-plus-circled"></i>
					<?php echo get_phrase('addmission_form');?>
            	</div>
            </div>
			<div class="panel-body">
				
                <?php echo form_open(base_url() . 'index.php?admin/student/create/' , array('class' => 'form-horizontal form-groups-bordered validate', 'enctype' => 'multipart/form-data'));?>
	
					<div class="form-group">
						<label for="field-1" class="col-sm-3 control-label"><?php echo get_phrase('name');?></label>

						<div class="col-sm-5">
							<input type="text" class="form-control" name="name" data-validate="required" data-message-required="<?php echo get_phrase('value_required');?>" value="" autofocus>
						</div>
					</div>

                <div class="form-group">
                    <label for="field-2" class="col-sm-3 control-label"><?php echo get_phrase('gender');?></label>

                    <div class="col-sm-5">
                        <select name="gender" class="form-control">
                            <option value=""><?php echo get_phrase('select');?></option>
                            <option value="male"><?php echo get_phrase('male');?></option>
                            <option value="female"><?php echo get_phrase('female');?></option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label for="field-2" class="col-sm-3 control-label"><?php echo get_phrase('Present Address');?></label>

                    <div class="col-sm-5">
                        <input type="text" class="form-control" name="present_address" value="" >
                    </div>
                </div>


                <div class="form-group">
                    <label for="field-2" class="col-sm-3 control-label"><?php echo get_phrase('phone');?></label>

                    <div class="col-sm-5">
                        <input type="text" class="form-control" name="phone" value="" >
                    </div>
                </div>


                <div class="form-group">
                    <label for="field-2" class="col-sm-3 control-label"><?php echo get_phrase('Parmanent Address');?></label>

                    <div class="col-sm-5">
                        <input type="text" class="form-control" name="parmanent_address" value="" >
                    </div>
                </div>


                <div class="form-group">
                    <label for="field-2" class="col-sm-3 control-label"><?php echo get_phrase('birthday');?></label>

                    <div class="col-sm-5">
                        <input type="text" class="form-control datepicker" name="birthday" value="" data-start-view="2">
                    </div>
                </div>



					<div class="form-group">
						<label for="field-2" class="col-sm-3 control-label"><?php echo get_phrase('parent');?></label>
                        
						<div class="col-sm-5">
							<select name="parent_id" class="form-control">
                              <option value=""><?php echo get_phrase('select');?></option>
                              <?php 
								$parents = $this->db->get('parent')->result_array();
								foreach($parents as $row):
									?>
                            		<option value="<?php echo $row['parent_id'];?>">
										<?php echo $row['father_name'];?>
                                    </option>
                                <?php
								endforeach;
							  ?>
                          </select>
						</div> 
					</div>
					
					<div class="form-group">
						<label for="field-2" class="col-sm-3 control-label"><?php echo get_phrase('class');?></label>
                        
						<div class="col-sm-5">
							<select name="class_id" class="form-control" data-validate="required" id="class_id" 
								data-message-required="<?php echo get_phrase('value_required');?>"
									onchange="return get_class_sections(this.value)">
                              <option value=""><?php echo get_phrase('select');?></option>
                              <?php 
								$classes = $this->db->get('class')->result_array();
								foreach($classes as $row):
									?>
                            		<option value="<?php echo $row['class_id'];?>">
											<?php echo $row['name'];?>
                                            </option>
                                <?php
								endforeach;
							  ?>
                          </select>
						</div> 
					</div>

					<div class="form-group">
						<label for="field-2" class="col-sm-3 control-label"><?php echo get_phrase('section');?></label>
		                    <div class="col-sm-5">
		                        <select name="section_id" class="form-control" id="section_selector_holder">
		                            <option value=""><?php echo get_phrase('select_class_first');?></option>
			                        
			                    </select>
			                </div>
					</div>
					
					<div class="form-group">
						<label for="field-2" class="col-sm-3 control-label"><?php echo get_phrase('Student ID');?></label>
                        
						<div class="col-sm-5">
							<input type="text" class="form-control" name="roll" value="" >
						</div> 
					</div>

					

                    
					<div class="form-group">
						<label for="field-1" class="col-sm-3 control-label"><?php echo get_phrase('email');?></label>
						<div class="col-sm-5">
							<input type="text" class="form-control" name="email" value="">
						</div>
					</div>
					
					<div class="form-group">
						<label for="field-2" class="col-sm-3 control-label"><?php echo get_phrase('password');?></label>
                        
						<div class="col-sm-5">
							<input type="password" class="form-control" name="password" value="" >
						</div> 
					</div>
	
					<div class="form-group">
						<label for="field-1" class="col-sm-3 control-label"><?php echo get_phrase('photo');?></label>
                        
						<div class="col-sm-5">
							<div class="fileinput fileinput-new" data-provides="fileinput">
								<div class="fileinput-new thumbnail" style="width: 100px; height: 100px;" data-trigger="fileinput">
									<img src="http://placehold.it/200x200" alt="...">
								</div>
								<div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 200px; max-height: 150px"></div>
								<div>
									<span class="btn btn-white btn-file">
										<span class="fileinput-new">Select image</span>
										<span class="fileinput-exists">Change</span>
										<input type="file" name="userfile" accept="image/*">
									</span>
									<a href="#" class="btn btn-orange fileinput-exists" data-dismiss="fileinput">Remove</a>
								</div>
							</div>
						</div>
					</div>


                <div class="form-group">
                    <label for="field-2" class="col-sm-8 control-label cl"><?php echo get_phrase('Information of The Student is Currently Studying Or Has Previously Studied(Not Applicable for PLAY Group)');?></label>
                    <div class="col-sm-12">
                        <table class="cp-studying" style="width:100%" border="1">
                            <tr>
                                <th>NAME OF INSTITUTION</th>
                                <th>CLASS</th>
                                <th>YEAR</th>
                                <th>POSITION</th>
                                <th>PASSED/PROMOTION ON TRIAL</th>
                            </tr>
                            <tr>
                                <td><input type="text" class="form-control" name="institution_1" value="" autofocus></td>
                                <td><input type="text" class="form-control" name="class_1" value="" autofocus></td>
                                <td><input type="text" class="form-control" name="year_1" value="" autofocus></td>
                                <td><input type="text" class="form-control" name="position_1" value="" autofocus></td>
                                <td><input type="text" class="form-control" name="passed_1" value="" autofocus></td>
                            </tr>
                            <tr>
                                <td><input type="text" class="form-control" name="institution_2" value="" autofocus></td>
                                <td><input type="text" class="form-control" name="class_2" value="" autofocus></td>
                                <td><input type="text" class="form-control" name="year_2" value="" autofocus></td>
                                <td><input type="text" class="form-control" name="position_2" value="" autofocus></td>
                                <td><input type="text" class="form-control" name="passed_2" value="" autofocus></td>
                            </tr>
                            <tr>
                                <td><input type="text" class="form-control" name="institution_3" value="" autofocus></td>
                                <td><input type="text" class="form-control" name="class_3" value="" autofocus></td>
                                <td><input type="text" class="form-control" name="year_3" value="" autofocus></td>
                                <td><input type="text" class="form-control" name="position_3" value="" autofocus></td>
                                <td><input type="text" class="form-control" name="passed_3" value="" autofocus></td>
                            </tr>
                        </table>
                    </div>
                </div>


                <div class="form-group">
                    <label for="field-2" class="col-sm-3 control-label"><?php echo get_phrase('Reason For Leaving Institution');?></label>

                    <div class="col-sm-5">
                        <textarea rows="5" cols="100" name="reason_for_leaving"></textarea>
                    </div>
                </div>

                <div class="form-group">
                    <label for="field-2" class="col-sm-5 control-label cl"><?php echo get_phrase('Names of Brothers/Sisters Currently Studying in This Institution');?></label>
                    <div class="col-sm-12">
                        <table class="cp-studying" style="width:100%" border="1">
                            <tr>
                                <th>NAME OF BROTHERS/SISTERS</th>
                                <th>CLASS</th>
                                <th>SECTION</th>
                            </tr>
                            <tr>
                                <td><input type="text" class="form-control" name="c_brother_1" value="" autofocus></td>
                                <td><input type="text" class="form-control" name="cb_class_1" value="" autofocus></td>
                                <td><input type="text" class="form-control" name="cb_section_1" value="" autofocus></td>
                            </tr>
                            <tr>
                                <td><input type="text" class="form-control" name="c_brother_2" value="" autofocus></td>
                                <td><input type="text" class="form-control" name="cb_class_2" value="" autofocus></td>
                                <td><input type="text" class="form-control" name="cb_section_2" value="" autofocus></td>
                            </tr>
                            <tr>
                                <td><input type="text" class="form-control" name="c_brother_3" value="" autofocus></td>
                                <td><input type="text" class="form-control" name="cb_class_3" value="" autofocus></td>
                                <td><input type="text" class="form-control" name="cb_section_3" value="" autofocus></td>
                            </tr>
                        </table>
                    </div>
                </div>


                <div class="form-group">
                    <label for="field-2" class="col-sm-5 control-label cl"><?php echo get_phrase('Names of Brothers/Sisters Previously Studying in This Institution');?></label>
                    <div class="col-sm-12">
                        <table class="cp-studying" style="width:100%" border="1">
                            <tr>
                                <th>NAME OF BROTHERS/SISTERS</th>
                                <th>CLASS</th>
                                <th>SECTION</th>
                            </tr>
                            <tr>
                                <td><input type="text" class="form-control" name="p_brothers_1" value="" autofocus></td>
                                <td><input type="text" class="form-control" name="pb_class_1" value="" autofocus></td>
                                <td><input type="text" class="form-control" name="pb_section_1" value="" autofocus></td>
                            </tr>
                            <tr>
                                <td><input type="text" class="form-control" name="p_brothers_2" value="" autofocus></td>
                                <td><input type="text" class="form-control" name="pb_class_2" value="" autofocus></td>
                                <td><input type="text" class="form-control" name="pb_section_2" value="" autofocus></td>
                            </tr>
                            <tr>
                                <td><input type="text" class="form-control" name="p_brothers_3" value="" autofocus></td>
                                <td><input type="text" class="form-control" name="pb_class_3" value="" autofocus></td>
                                <td><input type="text" class="form-control" name="pb_section_3" value="" autofocus></td>
                            </tr>
                        </table>
                    </div>
                </div>


                <div class="form-group">
                    <label for="field-2" class="col-sm-4 control-label cl"><?php echo get_phrase('This Section is to be Filled up by School Authority');?></label>
                    <div class="col-sm-12">
                        <table class="cp-studying" style="width:100%">
                            <tr>
                                <th>CLASS</th>
                                <th>MONTHLY TUTION FEES</th>
                                <th>ADMISSION FEES</th>
                                <th>EVALUATION FEES</th>
                                <th>VAT</th>
                                <th>TOTAL</th>

                            </tr>
                            <tr>
                                <td>
                                    <div class="form-group">
                                        <div class="col-sm-10">
                                            <select name="fee_class_id" class="form-control" data-validate="required" id="fee_class_id"
                                                    data-message-required="<?php echo get_phrase('value_required');?>">
                                                <option value=""><?php echo get_phrase('select class');?></option>
                                                <?php
                                                $classes = $this->db->get('class')->result_array();
                                                foreach($classes as $class):
                                                    $vat = $this->db->get_where('settings', array('type' => 'vat'))->row()->description;
                                                    $fee = $class['monthly_fee'].','.$class['admission_fee'].','.$class['evaluation_fee'].','.$vat;
                                                    ?>
                                                    <option class="<?php echo $fee;?>" value="<?php echo $class['class_id'];?>">
                                                        <?php echo $class['name'];?>
                                                    </option>
                                                <?php
                                                endforeach;
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                </td>
                                <td><input type="text" class="form-control" name="monthly_fees" id="monthly_fees" value="" autofocus readonly></td>
                                <td><span class="h_plus">+</span><input type="text" class="form-control h_input" name="admission_fees" id="admission_fees" value="" autofocus readonly></td>
                                <td><span class="h_plus">+</span><input type="text" class="form-control h_input" name="evaluation_fees" id="evaluation_fees" value="" autofocus readonly></td>
                                <td><span class="h_plus">+</span><input type="text" class="form-control h_input" name="vat" id="vat" value="" autofocus readonly></td>
                                <td><span class="h_plus">=</span><input type="text" class="form-control h_input" name="total" id="total" value="" autofocus readonly></td>
                            </tr>
                        </table>
                    </div>
                </div>



                <div class="form-group">
                    <label for="field-2" class="col-sm-3 control-label"><?php echo get_phrase('Student Admitted For The Session');?></label>

                    <div class="col-sm-3">
                        <select name="s_session" class="form-control" data-validate="required" id="month" onchange="" size="1">
                            <option value="01">January</option>
                            <option value="07">July</option>
<!--                            <option value="02">February</option>-->
<!--                            <option value="03">March</option>-->
<!--                            <option value="04">April</option>-->
<!--                            <option value="05">May</option>-->
<!--                            <option value="06">June</option>-->
<!--                            <option value="08">August</option>-->
<!--                            <option value="09">September</option>-->
<!--                            <option value="10">October</option>-->
<!--                            <option value="11">November</option>-->
<!--                            <option value="12">December</option>-->
                        </select>
                    </div>
                    <div class="col-sm-3">
                        <select name="year" class="form-control" data-validate="required" id="year" onchange="" size="1">
                            <?php
                            $year = date('Y');
                            for($i= $year;$i<=$year+5;$i++){
                                echo '<option value="'.$i.'">'.$i.'</option>';
                            }
                            ?>
                        </select>
                        <div class="s-year" style="display: none;">
                            <?php
                            $year = date('Y');
                            for($i= $year;$i<=$year+5;$i++){
                                echo '<option class="jan" value="'.$i.'">'.$i.'</option>';
                                echo '<option class="july" value="'.$i.'-'.($i+1).'">'.$i.'-'.($i+1).'</option>';
                            }
                            ?>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="field-2" class="col-sm-3 control-label"><?php echo get_phrase('Building Information');?></label>
                    <div class="col-sm-5">
                        <select name="building_info" class="form-control" data-validate="required" id="building_info"
                                data-message-required="<?php echo get_phrase('value_required');?>">
                            <option value=""><?php echo get_phrase('select building');?></option>
                            <?php
                            $buildings = $this->db->get('building')->result_array();
                            foreach($buildings as $building):
                                ?>
                                <option value="<?php echo $building['id'];?>">
                                    <?php echo $building['building_name'];?>
                                </option>
                            <?php
                            endforeach;
                            ?>
                        </select>
                    </div>
                </div>


                <div class="form-group">
						<div class="col-sm-offset-3 col-sm-5">
							<button type="submit" class="btn btn-info"><?php echo get_phrase('add_student');?></button>
						</div>
					</div>
                <?php echo form_close();?>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">

	function get_class_sections(class_id) {

    	$.ajax({
            url: '<?php echo base_url();?>index.php?admin/get_class_section/' + class_id ,
            success: function(response)
            {
                jQuery('#section_selector_holder').html(response);
            }
        });

    }
    $(function(){
        var m = $('#month').val();
        var html = '';
        if(m=="01"){
            $('.s-year').find('option').each(function(){
                var t = $(this).html();
                if($(this).hasClass( 'jan' )){
                    html += '<option value="'+t+'">'+t+'</option>';
                }
            });
            $('#year').html(html);
        }else{
            $('.s-year').find('option').each(function(){
                var t = $(this).html();
                if($(this).hasClass( 'july' )){
                    html += '<option value="'+t+'">'+t+'</option>';
                }
            });
            $('#year').html(html);
        }
    });

    $('#month').change(function(){
        var m = $('#month').val();
        var html = '';
        if(m=="01"){
            $('.s-year').find('option').each(function(){
                var t = $(this).html();
                if($(this).hasClass( 'jan' )){
                    html += '<option value="'+t+'">'+t+'</option>';
                }
            });
            $('#year').html(html);
        }else{
            $('.s-year').find('option').each(function(){
                var t = $(this).html();
                if($(this).hasClass( 'july' )){
                    html += '<option value="'+t+'">'+t+'</option>';
                }
            });
            $('#year').html(html);
        }
    });

    $('#fee_class_id').change(function(){
        var c = $('#fee_class_id option:selected').attr("class");
        var fees = c.split(",");
        var monthly_fee = parseFloat(fees[0]);
        var admission_fee = parseFloat(fees[1]);
        var evaluation_fee = parseFloat(fees[2]);
        var vat = parseFloat(fees[3]);
        var total = monthly_fee + admission_fee +  evaluation_fee;
        var final_total = total + (total * (vat/100));

        //Putting to necessary field
        $('#monthly_fees').val(monthly_fee);
        $('#admission_fees').val(admission_fee);
        $('#evaluation_fees').val(evaluation_fee);
        $('#vat').val(vat);
        $('#total').val(final_total);
    });

</script>