<!-- Footer -->
<footer class="main">
	&copy; 2015 <strong>School Manager</strong>.
    Developed by 
	<a href="http://googlestack.com"
    	target="_blank">GoogleStack</a>
</footer>
